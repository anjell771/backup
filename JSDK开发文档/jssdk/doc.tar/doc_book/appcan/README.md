# appcan 核心模块
appcan核心模块是appcan的基础模块，它是整个appcan 框架的核心，提供了模块管理功能，和基础的方法的实现
