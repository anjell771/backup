# appcan_base

##appcan基础类库
appcan整个框架依赖的基础库

###appcan.dom类库
参考[zetpo.js](http://zeptojs.com/ "zetpojs")类库，用法一致 

###appcan.Backbone类库
参考[Backbone.js](http://backbonejs.org "Backbone.js")类库，用法一致

###appcan._类库
参考[underscore.js](http://underscorejs.org "underscore.js")类库，用法一致

###appcan.underscore类库
参考[underscore.js](http://underscorejs.org "underscore.js")类库，用法一致 

###appcan.logs(msg)
把日志输出到控制台    
`msg`:要打印到控制台的消息

例如:
    
    //打印这段文字到控制台
    appcan.logs('这是一个打印消息');
